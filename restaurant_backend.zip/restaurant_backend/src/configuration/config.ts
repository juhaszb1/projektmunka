export class Config {
     public static readonly SERVER_PORT = 5500;
     public static readonly MONGO_CONNECTION_STRING = "mongodb+srv://GMrestaurant22:Nacmgg2022_@cluster0.snbdn0s.mongodb.net/?retryWrites=true&w=majority";
}