import {RestaurantService} from "../services/restaurant.service";
import {Request, Response} from "express";
import {PutRestaurant} from "../models/restaurant.model";

export class RestaurantController {
    private readonly restaurantService = new RestaurantService();
    public getRestaurant = (req: Request, res: Response) => {
        this.restaurantService.readRestaurant(req.params.rid)
            .then((restaurant) => {
                res.status(200).json(restaurant);
            })
            .catch((error) => {
                res.status(404).json(error);
            })
    }

    public putRestaurant = (req: Request, res: Response) => {
        const restaurant: PutRestaurant = {
            menu: req.body.menu,
            drinks: req.body.drinks
        }
        this.restaurantService.updateRestaurant(req.params.rid,restaurant)
            .then((restaurant)=>{
                res.status(202).json(restaurant);
            })
            .catch((error) =>{
                res.status(404).json(error);
            })
    }
}