import {PutRestaurant, Restaurant} from "../models/restaurant.model";
import {RestaurantSchema} from "../models/schemas/restaurant.schema";


export class RestaurantRepository {
    public async getRestaurant(restaurantID: string): Promise<Restaurant | null> {
        const restaurant = await RestaurantSchema.findOne({restaurantID: restaurantID});
        if (!restaurant) throw new Error("not found")
        return restaurant;
    }

    public async putRestaurant(restaurantID: string, updatedRestaurant:PutRestaurant): Promise<Restaurant | null> {
        return await RestaurantSchema.findOne({restaurantID: restaurantID})
            .then((searchedRestaurant)=>{
                if (searchedRestaurant){
                    searchedRestaurant.set(updatedRestaurant);
                    searchedRestaurant.save();
                    return searchedRestaurant
                }
                throw new Error("not found")
            })
    }
}