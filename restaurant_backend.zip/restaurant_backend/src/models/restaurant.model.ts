import {DrinkGroup} from "./drink-group.model";
import {Menu} from "./menu.model";

export interface Restaurant{
    id : string;
    restaurantID : string;
    drinks : DrinkGroup[];
    menu : Menu[];
}

export interface PutRestaurant{
    drinks : DrinkGroup[];
    menu : Menu[];
}