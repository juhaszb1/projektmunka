import mongoose from "mongoose";
import {DrinkItem} from "../drink-item.model";
import {DrinkGroup} from "../drink-group.model";
import {Menu} from "../menu.model";
import {Restaurant} from "../restaurant.model";

const drinkItemSchema = new mongoose.Schema<DrinkItem>({
        id: {type: String, required: true},
        name: {type: String, required: true},
        price: {type: Number, required: true},

    },
    {versionKey: false});
const drinkGroupSchema = new mongoose.Schema<DrinkGroup>({
        nameOfType: {type: String, required: true},
        items: {type: [drinkItemSchema], required: true},
        afa: {type: Number, required: true},

    },
    {versionKey: false});

const menuSchema = new mongoose.Schema<Menu>({
        name: {type: String, required: true},
        nickname: {type: String, required: false},
        items: {type: [String], required: false},
        price: {type: Number, required: true},
        restaurantID: {type: String, required: true},
        type: {type: String, required: true},
        afa: {type: Number, required: true}
    },
    {
        versionKey: false
    });

const restaurantSchema = new mongoose.Schema<Restaurant>({
    restaurantID: {type: String, required: true},
    drinks: {type: [drinkGroupSchema], required: true},
    menu: {type: [menuSchema], required: true}
},
    {
        versionKey : false
    }
);
export const RestaurantSchema = mongoose.model("restaurant", restaurantSchema, "restaurant");
