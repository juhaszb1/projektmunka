export interface DrinkItem {
    id: string;
    name: string;
    price: number;
}





