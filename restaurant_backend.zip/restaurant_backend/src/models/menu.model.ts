export interface Menu {
    id: string;
    name: string;
    nickname: string;
    items: string[];
    price: number;
    restaurantID: string;
    type: string;
    afa: number;

}

export interface PostMenu{
    name: string;
    nickname: string;
    items: string[];
    price: number;
    restaurantID: string;
    type: string;
    afa: number;
}
export const mapToMenu = (menu: any): Menu | null => {
    if (!menu) return null;

    return {
        id: menu._id,
        name: menu.name,
        nickname: menu.nickname,
        items: menu.items,
        price: menu.price,
        restaurantID: menu.restaurantID,
        type: menu.type,
        afa: menu.afa
    }
}