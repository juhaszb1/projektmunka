import {DrinkItem} from "./drink-item.model";

export interface DrinkGroup {
    nameOfType: string;
    items: DrinkItem[];
    afa: number;
}

