import express, {Application} from "express";
import cors from "cors";
import {Config} from "./configuration/config";
import {Logger} from "./logger/Log";
import * as mongoose from "mongoose";
import {RestaurantRoutes} from "./routes/restaurant.route";


const start = () => {
    const app: Application = express();
    app.use(express.json());
    app.use(cors({origin: "*"}));
    app.use("/api/restaurant",RestaurantRoutes);
    Logger.info("MongoDb connection is active!");
    app.listen(Config.SERVER_PORT, () => Logger.success("Server is run at 5500 port!"))
}

const errorHandler = () => {
    Logger.error("Mongo connection is fail! 500: SERVER ERROR")
}
mongoose.set('strictQuery', false)
mongoose.connect(Config.MONGO_CONNECTION_STRING).then(start).catch(errorHandler);