import express from "express";
import {RestaurantController} from "../controllers/restaurant.controller";

const controller = new RestaurantController();
const router = express.Router();

router.get("/:rid",controller.getRestaurant);
router.put("/:rid",controller.putRestaurant);

export {router as RestaurantRoutes};
