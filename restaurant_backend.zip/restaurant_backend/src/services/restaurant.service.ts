import {PutRestaurant, Restaurant} from "../models/restaurant.model";
import {RestaurantRepository} from "../repo/restaurant.repo";

export class RestaurantService {
    private readonly repository = new RestaurantRepository();

    public async readRestaurant(restaurantID: string): Promise<Restaurant | null> {
        return this.repository.getRestaurant(restaurantID);
    }

    public async updateRestaurant(restaurantID: string,updatedRestaurant:PutRestaurant): Promise<Restaurant | null> {
        return this.repository.putRestaurant(restaurantID,updatedRestaurant);
    }
}